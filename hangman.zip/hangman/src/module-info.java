module hangman {
}